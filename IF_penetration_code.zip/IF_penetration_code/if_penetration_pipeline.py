#!/usr/bin/env python3
"""
if_penetration_pipeline.py
==========================
Depth-attenuation analysis of whole-mount spheroid immunofluorescence z-stacks.

Implements, end to end, the procedure described in Supplementary Information
Section S2.7 of:

    "Spatiotemporal Raman Spectroscopy and Machine Learning Classification
     Reveal Thrombomodulin-Associated Metabolic Compartmentalization in
     Hypoxic Melanoma Spheroids"

--------------------------------------------------------------------------
WHY THIS EXISTS
--------------------------------------------------------------------------
Whole-mount IF of an intact spheroid is degraded with depth by two processes:
limited antibody penetration, and optical attenuation (worsened by refractive
index mismatch when an air objective is focused into aqueous fixed tissue).

Both act on EVERY channel of a given specimen. So a raw radial intensity
profile conflates marker biology with a common attenuation term.

The geometry makes this concrete. For a sphere of radius R imaged along z, a
voxel in the equatorial plane at normalized radius rho has overlying tissue
thickness

        t(rho) = R * sqrt(1 - rho^2)

maximal at the center (t = R), zero at the rim. Attenuation ALONE therefore
predicts a bright rim and a dark core, with no biological difference required.

The nuclear counterstain provides the internal control: Hoechst labels all
nuclei, so its radial profile should be roughly flat absent attenuation.
Dividing each marker by Hoechst at matched radius cancels the shared
multiplicative attenuation to first order.

--------------------------------------------------------------------------
STAGES
--------------------------------------------------------------------------
  extract   segment, pick equatorial plane, radial + axial profiles   -> CSVs
  analyze   nuclear deficit, channel collapse, normalization, stats   -> CSVs + report
  figure    six-panel summary figure                                  -> PNG

--------------------------------------------------------------------------
INPUT
--------------------------------------------------------------------------
A folder of single-channel TIFF z-stacks named

    {cellline}_{batch}_{spheroid}_{channel}.tif

e.g.  A2058_B1_S1_Hoechst.tif   A2058TM_B2_S3_p27.tif

Constraints:
  * no underscores inside any of the four fields
  * every spheroid must have the nuclear channel (default "Hoechst")
  * all channels of one spheroid must share dimensions and optical plane set

--------------------------------------------------------------------------
USAGE
--------------------------------------------------------------------------
    pip install -r requirements.txt

    python if_penetration_pipeline.py --input ./tiffs --output ./results \
        --pixel-size 0.6215 --z-step 5.0 \
        --group-a A2058 --group-b A2058TM

    # re-run stats/figure without re-reading the image stacks
    python if_penetration_pipeline.py --input ./tiffs --output ./results \
        --stages analyze,figure

--------------------------------------------------------------------------
OUTPUTS
--------------------------------------------------------------------------
  geometry.csv          per-spheroid: diameter, equatorial plane, stack span
  prof_equatorial.csv   radial profiles, all spheroids x channels x bins
  prof_axial.csv        per-slice rim and core intensity (depth decay)
  normalized_profiles.csv  marker / Hoechst at matched radius
  core_stats.csv        core/whole ratios + Welch p, raw vs normalized, swept
  channel_collapse.csv  across-channel spread of the rim-normalized profile
  report.txt            human-readable summary of every test
  figure.png            six-panel summary

--------------------------------------------------------------------------
Author: analysis pipeline for the CEJ revision. MIT license.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import warnings
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
from scipy import ndimage as ndi
from scipy import stats

warnings.filterwarnings("ignore")

try:
    import tifffile
    from skimage.filters import threshold_otsu, gaussian, apply_hysteresis_threshold
    from skimage.morphology import convex_hull_image
except ImportError:
    sys.exit("Missing dependencies. Run:  pip install -r requirements.txt")

FNAME = re.compile(r"^(?P<cell_line>[^_]+)_(?P<batch>[^_]+)_(?P<spheroid>[^_]+)"
                   r"_(?P<channel>[^_]+)\.tiff?$", re.IGNORECASE)

# Okabe-Ito subset; validated colorblind-safe in this fixed order.
PALETTE = {"Hoechst": "#0072B2", "CAIX": "#D55E00", "COUPTF1": "#009E73",
           "Ki67": "#E69F00", "p27": "#CC79A7"}
NICE = {"Hoechst": "Hoechst", "CAIX": "CA IX", "COUPTF1": "COUP-TF1",
        "Ki67": "Ki-67", "p27": "p27"}


# ==========================================================================
# STAGE 1 — extraction
# ==========================================================================

@dataclass
class Geometry:
    spheroid: str
    cell_line: str
    batch: str
    rep: str
    z_eq: int
    n_z: int
    R_px: float
    R_um: float
    diam_um: float
    z_span_um: float


def segment_slice(img: np.ndarray, sigma: float = 2.0, k_low: float = 0.3,
                  frame: int = 32) -> np.ndarray | None:
    """Per-slice cross-section of the spheroid as the CONVEX HULL of the segmented tissue.

    Why hysteresis: in deep optical sections the peripheral nuclei nearest the
    objective remain bright while the rest of the section is dim. A single Otsu
    threshold then separates bright from dim nuclei rather than tissue from
    background, and only a bright crescent is segmented. Hysteresis keeps every
    pixel above a low threshold that is connected to a pixel above the Otsu
    threshold, so the dim part of the section is recovered while unconnected
    background is not.

    Why a low threshold anchored to background: in dim sections the Otsu value
    approaches the background level, so a fixed fraction of Otsu can fall below
    background and flood the field. The low threshold is placed a fraction
    k_low of the way from the background level (median of a `frame`-pixel
    border) to the Otsu threshold.

    Why a convex hull: the attenuated core is darker than the rim, so the
    thresholded region can be ring-shaped with gaps; the hull does not depend
    on ring closure.

    Steps: Gaussian (sigma) -> Otsu (high) and bg + k_low*(Otsu - bg) (low) ->
    hysteresis -> 9x9 closing -> keep the largest component plus any component
    >= 5% of its area whose centroid lies within 1.5 equivalent radii of it
    (excludes distant debris) -> convex hull.
    """
    sm = gaussian(img, sigma=sigma, preserve_range=True)
    try:
        hi = threshold_otsu(sm)
    except ValueError:
        return None
    border = np.concatenate([sm[:frame].ravel(), sm[-frame:].ravel(),
                             sm[:, :frame].ravel(), sm[:, -frame:].ravel()])
    bg = float(np.median(border))
    lo = bg + k_low * (hi - bg) if hi > bg else hi
    m = ndi.binary_closing(apply_hysteresis_threshold(sm, lo, hi), np.ones((9, 9)))
    lab, n = ndi.label(m)
    if not n:
        return None
    idx = np.arange(1, n + 1)
    sizes = np.asarray(ndi.sum(m, lab, idx))
    big = int(np.argmax(sizes))
    cents = np.asarray(ndi.center_of_mass(m, lab, idx))
    r_big = np.sqrt(sizes[big] / np.pi)
    dist = np.hypot(*(cents - cents[big]).T)
    keep = idx[(sizes >= 0.05 * sizes[big]) & (dist <= 1.5 * max(r_big, 1.0))]
    sel = np.isin(lab, keep)
    if not sel.any():
        return None
    return convex_hull_image(sel)


def index_folder(folder: str, nuclear: str) -> dict:
    files, skipped = {}, []
    for fn in sorted(os.listdir(folder)):
        if not fn.lower().endswith((".tif", ".tiff")):
            continue
        m = FNAME.match(fn)
        if not m:
            skipped.append(fn)
            continue
        d = m.groupdict()
        key = (d["cell_line"], d["batch"], d["spheroid"])
        files.setdefault(key, {})[d["channel"]] = os.path.join(folder, fn)
    if skipped:
        print(f"[warn] {len(skipped)} file(s) ignored (name pattern): "
              f"{', '.join(skipped[:5])}{' ...' if len(skipped) > 5 else ''}")
    bad = [k for k, v in files.items()
           if not any(c.lower() == nuclear.lower() for c in v)]
    for k in bad:
        print(f"[warn] {'_'.join(k)}: no '{nuclear}' channel — skipped")
        files.pop(k)
    return files


def extract(folder, out, nuclear, n_bins, pixel_size, z_step, bg_gap):
    files = index_folder(folder, nuclear)
    if not files:
        sys.exit("No usable spheroids found.")

    radial, axial, geoms = [], [], []

    for (cl, batch, rep), chans in sorted(files.items()):
        name = f"{cl}_{batch}_{rep}"
        nuc_key = next(c for c in chans if c.lower() == nuclear.lower())

        nuc = tifffile.imread(chans[nuc_key]).astype(np.float32)
        if nuc.ndim != 3:
            print(f"[warn] {name}: nuclear stack is not 3D — skipped")
            continue
        n_z = nuc.shape[0]

        # --- S2.7.2 segmentation + equatorial plane ---------------------
        masks = [segment_slice(nuc[z]) for z in range(n_z)]
        areas = np.array([0 if m is None else int(m.sum()) for m in masks])
        if areas.max() == 0:
            print(f"[warn] {name}: segmentation failed — skipped")
            continue
        # 3-slice median filter so a single spurious slice cannot win
        z_eq = int(np.argmax(ndi.median_filter(areas.astype(float), size=3, mode='mirror')))
        m_eq = masks[z_eq]
        cy, cx = ndi.center_of_mass(m_eq)
        R_px = float(np.sqrt(areas[z_eq] / np.pi))

        geoms.append(Geometry(name, cl, batch, rep, z_eq, n_z, R_px,
                              R_px * pixel_size, 2 * R_px * pixel_size,
                              n_z * z_step))

        h, w = m_eq.shape
        yy, xx = np.mgrid[0:h, 0:w]
        rho = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / R_px
        edges = np.linspace(0.0, 1.0, n_bins + 1)

        for ch, path in sorted(chans.items()):
            stack = tifffile.imread(path).astype(np.float32)
            if stack.shape != nuc.shape:
                print(f"[warn] {name}/{ch}: shape mismatch — skipped")
                continue
            plane = stack[z_eq]

            # --- S2.7.3 background: outside a dilated mask --------------
            outside = ~ndi.binary_dilation(m_eq, np.ones((2 * bg_gap + 1,) * 2))
            bg = float(np.median(plane[outside])) if outside.sum() > 100 else 0.0

            # --- S2.7.3 radial profile at the equatorial plane ----------
            for i in range(n_bins):
                lo, hi = edges[i], edges[i + 1]
                sel = m_eq & (rho >= lo) & ((rho < hi) if i < n_bins - 1 else (rho <= hi))
                if not sel.any():
                    continue
                v = plane[sel]
                radial.append(dict(
                    spheroid=name, cell_line=cl, batch=batch, rep=rep,
                    channel=ch, bin=i, r_mid=(lo + hi) / 2,
                    mean=float(v.mean()), mean_bgsub=float(v.mean() - bg),
                    median=float(np.median(v)), sd=float(v.std(ddof=1)) if v.size > 1 else 0.0,
                    n_px=int(sel.sum()), bg=bg))

            # --- S2.7.4 axial decay: rim vs core of each slice ----------
            for z in range(n_z):
                m = masks[z]
                if m is None or m.sum() < 500:
                    continue
                cyz, cxz = ndi.center_of_mass(m)
                Rz = np.sqrt(m.sum() / np.pi)
                rz = np.sqrt((xx - cxz) ** 2 + (yy - cyz) ** 2) / Rz
                rim, core = m & (rz > 0.85), m & (rz < 0.30)
                axial.append(dict(
                    spheroid=name, cell_line=cl, batch=batch, channel=ch,
                    z=z, z_um=z * z_step, area_px=int(m.sum()),
                    rim=float(stack[z][rim].mean() - bg) if rim.any() else np.nan,
                    core=float(stack[z][core].mean() - bg) if core.any() else np.nan))

        print(f"  {name:<16} d = {2*R_px*pixel_size:6.1f} um   "
              f"equatorial plane z = {z_eq}/{n_z}   channels = {len(chans)}")

    gdf = pd.DataFrame([asdict(g) for g in geoms])
    rdf = pd.DataFrame(radial)
    adf = pd.DataFrame(axial)
    gdf.to_csv(os.path.join(out, "geometry.csv"), index=False)
    rdf.to_csv(os.path.join(out, "prof_equatorial.csv"), index=False)
    adf.to_csv(os.path.join(out, "prof_axial.csv"), index=False)
    return gdf, rdf, adf


# ==========================================================================
# STAGE 2 — analysis
# ==========================================================================

def core_whole(g: pd.DataFrame, frac: float, col: str) -> float:
    """S2.7.6  CWR(f) = <I>_{rho<f} / <I>_{rho<=1}, pixel-count weighted."""
    g = g.dropna(subset=[col])
    if g.empty:
        return np.nan
    core = g[g.r_mid < frac]
    if core.empty or not np.isfinite(np.average(g[col], weights=g.n_px)):
        return np.nan
    denom = np.average(g[col], weights=g.n_px)
    if denom == 0:
        return np.nan
    return float(np.average(core[col], weights=core.n_px) / denom)


def analyze(out, rdf, adf, gdf, nuclear, ga, gb, sweep):
    R, W = [], lambda s: (R.append(s), print(s))[0]
    W("=" * 76)
    W("IF DEPTH-ATTENUATION ANALYSIS")
    W("=" * 76)
    W(f"spheroids {gdf.spheroid.nunique()}   channels {sorted(rdf.channel.unique())}")
    W(f"diameters {gdf.diam_um.min():.0f}-{gdf.diam_um.max():.0f} um   "
      f"axial span {gdf.z_span_um.min():.0f}-{gdf.z_span_um.max():.0f} um")
    W("  -> the stack does not span the full spheroid depth\n"
      if (gdf.z_span_um < gdf.diam_um).all() else "")

    # ---- S2.7.4 nuclear deficit ---------------------------------------
    W("-" * 76); W("TEST 1  nuclear core deficit  (Hoechst labels every nucleus)"); W("-" * 76)
    t1 = []
    for sp, g in rdf[rdf.channel == nuclear].groupby("spheroid"):
        core = g[g.r_mid < .3].mean_bgsub.mean()
        rim = g[g.r_mid > .8].mean_bgsub.mean()
        t1.append(dict(spheroid=sp, cell_line=g.cell_line.iloc[0],
                       core=core, rim=rim, core_rim=core / rim if rim else np.nan))
    t1 = pd.DataFrame(t1)
    for cl, g in t1.groupby("cell_line"):
        W(f"  {cl:<10} core/rim = {g.core_rim.mean():.3f} +/- {g.core_rim.std():.3f}  (n={len(g)})")
    med = t1.core_rim.median()
    W(f"  MEDIAN across all spheroids = {med:.3f}")
    W("  -> severe depth-dependent loss; raw radial profiles are not interpretable"
      if med < .5 else "  -> nuclear channel roughly flat; attenuation not limiting")

    # ---- channel collapse ---------------------------------------------
    W("\n" + "-" * 76)
    W("TEST 2  do all channels share one radial profile?")
    W("-" * 76)
    W("  Each channel normalized to its OWN rim, then SD taken across channels.")
    coll = []
    for cl, g in rdf.groupby("cell_line"):
        curves = []
        for ch, gg in g.groupby("channel"):
            m = gg.groupby("r_mid").mean_bgsub.mean()
            rim = m[m.index > .8].mean()
            if rim:
                curves.append((m / rim).values)
        if len(curves) < 2:
            continue
        sd = float(np.nanmean(np.nanstd(np.vstack(curves), axis=0)))
        coll.append(dict(cell_line=cl, across_channel_sd=sd, n_channels=len(curves)))
        W(f"  {cl:<10} across-channel SD = {sd:.3f}  ({len(curves)} channels)")
    coll = pd.DataFrame(coll)
    W("  -> a low SD means one shared attenuation process explains the pattern;")
    W("     a high SD means genuine marker-specific structure is present.")

    # ---- S2.7.5 normalization + S2.7.6 stats --------------------------
    W("\n" + "-" * 76)
    W(f"TEST 3  core/whole ratio, RAW vs {nuclear}-NORMALIZED")
    W("-" * 76)
    wide = rdf.pivot_table(index=["spheroid", "cell_line", "r_mid", "n_px"],
                           columns="channel", values="mean_bgsub").reset_index()
    markers = [c for c in rdf.channel.unique() if c != nuclear]
    norm_rows, res = [], []
    for ch in markers:
        if ch not in wide.columns:
            continue
        sub = wide.dropna(subset=[ch, nuclear]).copy()
        if sub.empty:
            continue
        sub["raw"] = sub[ch]
        sub["norm"] = sub[ch] / sub[nuclear].replace(0, np.nan)
        nr = sub[["spheroid", "cell_line", "r_mid", "norm"]].copy()
        nr["channel"] = ch
        norm_rows.append(nr)
        for mode in ("raw", "norm"):
            for f in sweep:
                vals = {}
                for cl in (ga, gb):
                    v = [core_whole(g, f, mode)
                         for _, g in sub[sub.cell_line == cl].groupby("spheroid")]
                    vals[cl] = [x for x in v if np.isfinite(x)]
                if min(len(vals[ga]), len(vals[gb])) < 2:
                    continue
                t, p = stats.ttest_ind(vals[ga], vals[gb], equal_var=False)
                res.append(dict(channel=ch, mode=mode, core_fraction=f,
                                mean_a=np.mean(vals[ga]), sd_a=np.std(vals[ga], ddof=1),
                                mean_b=np.mean(vals[gb]), sd_b=np.std(vals[gb], ddof=1),
                                n_a=len(vals[ga]), n_b=len(vals[gb]),
                                t=t, p=p, significant=p < .05))
    res = pd.DataFrame(res)
    norm = pd.concat(norm_rows, ignore_index=True) if norm_rows else pd.DataFrame()

    if not res.empty:
        W(f"  {'marker':<10}{'mode':<12}{'sig/total':>10}{'min p':>10}   "
          f"{ga} vs {gb} at f=0.4")
        for ch in res.channel.unique():
            for mode in ("raw", "norm"):
                s = res[(res.channel == ch) & (res["mode"] == mode)]
                if s.empty:
                    continue
                at4 = s[np.isclose(s.core_fraction, .4)]
                desc = (f"{at4.mean_a.iloc[0]:.2f}+/-{at4.sd_a.iloc[0]:.2f} vs "
                        f"{at4.mean_b.iloc[0]:.2f}+/-{at4.sd_b.iloc[0]:.2f}, "
                        f"p={at4.p.iloc[0]:.4f}") if len(at4) else ""
                W(f"  {ch:<10}{mode:<12}{f'{int(s.significant.sum())}/{len(s)}':>10}"
                  f"{s.p.min():>10.4f}   {desc}")
        W("\n  SURVIVAL:")
        for ch in res.channel.unique():
            r = res[(res.channel == ch) & (res["mode"] == "raw")]
            n = res[(res.channel == ch) & (res["mode"] == "norm")]
            if r.empty or n.empty:
                continue
            rs, ns = int(r.significant.sum()), int(n.significant.sum())
            verdict = ("survives normalization" if rs and ns else
                       "LOST — raw result explained by attenuation" if rs and not ns else
                       "EMERGES after normalization" if ns and not rs else
                       "absent in both")
            W(f"    {ch:<10} raw {rs}/{len(r)} -> norm {ns}/{len(n)} : {verdict}")

    t1.to_csv(os.path.join(out, "test1_nuclear_deficit.csv"), index=False)
    coll.to_csv(os.path.join(out, "channel_collapse.csv"), index=False)
    res.to_csv(os.path.join(out, "core_stats.csv"), index=False)
    if not norm.empty:
        norm.to_csv(os.path.join(out, "normalized_profiles.csv"), index=False)
    with open(os.path.join(out, "report.txt"), "w") as fh:
        fh.write("\n".join(R) + "\n")
    return res


# ==========================================================================
# STAGE 3 — figure
# ==========================================================================

def figure(out, rdf, res, nuclear, ga, gb, labels=None):
    """labels: optional {cell_line: display name} for figure titles."""
    labels = labels or {}
    La, Lb = labels.get(ga, ga), labels.get(gb, gb)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    INK, MUT, GRID = "#1b1b1b", "#5a5a5a", "#dcdcda"
    plt.rcParams.update({"font.size": 8, "axes.edgecolor": MUT, "axes.labelcolor": INK,
                         "text.color": INK, "xtick.color": MUT, "ytick.color": MUT,
                         "axes.linewidth": .8, "figure.facecolor": "white",
                         "axes.facecolor": "white", "legend.frameon": False})
    pal = {c: PALETTE.get(c, "#777777") for c in rdf.channel.unique()}
    nice = {c: NICE.get(c, c) for c in rdf.channel.unique()}

    def style(ax):
        ax.grid(True, color=GRID, lw=.6, zorder=0); ax.set_axisbelow(True)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)

    fig = plt.figure(figsize=(9.5, 7.6))
    gs = fig.add_gridspec(2, 3, hspace=.46, wspace=.34, top=.90, bottom=.13)
    lines = [ga, gb]

    for j, cl in enumerate(lines):                                  # A, B
        ax = fig.add_subplot(gs[0, j]); style(ax)
        for ch, c in pal.items():
            s = rdf[(rdf.cell_line == cl) & (rdf.channel == ch)]
            if s.empty:
                continue
            m = s.groupby("r_mid").mean_bgsub.mean()
            rim = m[m.index > .8].mean()
            if rim:
                ax.plot(m.index, m.values / rim, color=c, lw=2, marker="o", ms=3.5, zorder=3)
        ax.axhline(1, color=MUT, lw=.8, ls=":")
        ax.set_xlabel("normalized radius  (0 = center, 1 = rim)")
        ax.set_ylabel("intensity / own rim intensity"); ax.set_ylim(0, 1.55)
        ax.set_title(f"{'AB'[j]}   {labels.get(cl, cl)} — raw", loc="left", fontsize=9, weight="bold")

    ax = fig.add_subplot(gs[0, 2]); style(ax)                        # C
    h = rdf[rdf.channel == nuclear]; rng = np.random.default_rng(1)
    for i, cl in enumerate(lines):
        v = [g[g.r_mid < .3].mean_bgsub.mean() / g[g.r_mid > .8].mean_bgsub.mean()
             for _, g in h[h.cell_line == cl].groupby("spheroid")]
        ax.scatter(np.full(len(v), i) + np.linspace(-.18, .18, len(v)), v, s=34,
                   color=pal.get(nuclear, "#0072B2"), zorder=3,
                   edgecolor="white", linewidth=.8)
        ax.hlines(np.mean(v), i - .2, i + .2, color=INK, lw=2, zorder=4)
    ax.axhline(1, color=MUT, lw=.9, ls="--")
    ax.text(.5, 1.03, "expected if no attenuation", ha="center", fontsize=7, color=MUT)
    ax.set_xticks(range(len(lines))); ax.set_xticklabels([labels.get(c, c) for c in lines])
    ax.set_xlim(-.5, len(lines) - .5); ax.set_ylim(0, 1.18)
    ax.set_ylabel(f"{nice.get(nuclear, nuclear)}  core / rim")
    ax.set_title("C   nuclear signal lost at core", loc="left", fontsize=9, weight="bold")

    wide = rdf.pivot_table(index=["spheroid", "cell_line", "r_mid"],
                           columns="channel", values="mean_bgsub").reset_index()
    for j, cl in enumerate(lines):                                   # D, E
        ax = fig.add_subplot(gs[1, j]); style(ax); top = 0
        for ch, c in pal.items():
            if ch == nuclear or ch not in wide.columns:
                continue
            s = wide[wide.cell_line == cl].dropna(subset=[ch, nuclear])
            if s.empty:
                continue
            m = s.assign(n=s[ch] / s[nuclear]).groupby("r_mid").n.mean()
            ax.plot(m.index, m.values, color=c, lw=2, marker="o", ms=3.5, zorder=3)
            top = max(top, float(np.nanmax(m.values)))
        ax.set_xlabel("normalized radius"); ax.set_ylabel(f"marker / {nice.get(nuclear, nuclear)}")
        ax.set_ylim(0, top * 1.12 if top else 1)
        ax.set_title(f"{'DE'[j]}   {labels.get(cl, cl)} — {nice.get(nuclear, nuclear)}-normalized",
                     loc="left", fontsize=9, weight="bold")

    ax = fig.add_subplot(gs[1, 2]); style(ax); hF = []               # F
    show = [c for c in ("p27", "Ki67") if c in set(res.channel)] or \
           list(dict.fromkeys(res.channel))[:2]
    for ch in show:
        for mode, ls, lab in (("raw", ":", "raw"), ("norm", "-", "normalized")):
            s = res[(res.channel == ch) & (res["mode"] == mode)].sort_values("core_fraction")
            if s.empty:
                continue
            ax.plot(s.core_fraction, s.p, color=pal.get(ch, "#777"), lw=2, ls=ls,
                    marker="o", ms=3.5, zorder=3)
            hF.append(Line2D([0], [0], color=pal.get(ch, "#777"), lw=2, ls=ls,
                             marker="o", ms=3.5, label=f"{nice.get(ch, ch)} {lab}"))
    ax.axhline(.05, color=INK, lw=1, ls="--")
    ax.text(.45, .044, "p = 0.05", fontsize=7, color=INK, ha="center", va="top")
    ax.set_yscale("log"); ax.set_ylim(5e-4, 1.2)
    ax.set_xlabel("core radius fraction"); ax.set_ylabel(f"p  ({La} vs {Lb})")
    ax.set_title("F   significance vs correction", loc="left", fontsize=9, weight="bold")
    if hF:
        ax.legend(handles=hF, fontsize=6.8, loc="upper left",
                  bbox_to_anchor=(0, -.30), ncol=2, columnspacing=1.0, handlelength=2.2)

    handles = [Line2D([0], [0], color=c, lw=2, marker="o", ms=4, label=nice[k])
               for k, c in pal.items()]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, .975),
               ncol=len(handles), fontsize=8, columnspacing=2.0, handlelength=2.2)
    fig.text(.5, .995, "Depth-dependent signal loss in whole-mount spheroid immunofluorescence",
             ha="center", fontsize=10, weight="bold")
    path = os.path.join(out, "figure.png")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    fig.savefig(path.replace(".png", ".pdf"), bbox_inches="tight")
    print(f"  wrote {path} (+ .pdf)")


# ==========================================================================
def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True, help="folder of single-channel TIFF z-stacks")
    ap.add_argument("--output", default="./results")
    ap.add_argument("--stages", default="extract,analyze,figure",
                    help="comma-separated subset of extract,analyze,figure")
    ap.add_argument("--nuclear-channel", default="Hoechst")
    ap.add_argument("--group-a", default=None, help="first cell line, e.g. A2058")
    ap.add_argument("--group-b", default=None, help="second cell line, e.g. A2058TM")
    ap.add_argument("--label-a", default=None, help="display name for group A in figures")
    ap.add_argument("--label-b", default=None, help="display name for group B in figures")
    ap.add_argument("--bins", type=int, default=20, help="radial bins (default 20)")
    ap.add_argument("--pixel-size", type=float, default=1.0, help="um per pixel")
    ap.add_argument("--z-step", type=float, default=1.0, help="um between slices")
    ap.add_argument("--bg-gap", type=int, default=10, help="mask dilation before background (px)")
    ap.add_argument("--core-sweep", default="0.2,0.8,0.1", help="min,max,step")
    a = ap.parse_args()

    os.makedirs(a.output, exist_ok=True)
    stages = {s.strip() for s in a.stages.split(",")}
    lo, hi, st = (float(x) for x in a.core_sweep.split(","))
    sweep = np.round(np.arange(lo, hi + 1e-9, st), 2)

    if "extract" in stages:
        print("[1/3] extracting profiles")
        gdf, rdf, adf = extract(a.input, a.output, a.nuclear_channel, a.bins,
                                a.pixel_size, a.z_step, a.bg_gap)
    else:
        gdf = pd.read_csv(os.path.join(a.output, "geometry.csv"))
        rdf = pd.read_csv(os.path.join(a.output, "prof_equatorial.csv"))
        adf = pd.read_csv(os.path.join(a.output, "prof_axial.csv"))

    lines = sorted(rdf.cell_line.unique())
    ga = a.group_a or (lines[0] if lines else None)
    gb = a.group_b or (lines[1] if len(lines) > 1 else None)

    res = pd.DataFrame()
    if "analyze" in stages:
        print("\n[2/3] analyzing")
        res = analyze(a.output, rdf, adf, gdf, a.nuclear_channel, ga, gb, sweep)
    elif os.path.exists(os.path.join(a.output, "core_stats.csv")):
        res = pd.read_csv(os.path.join(a.output, "core_stats.csv"))

    if "figure" in stages:
        print("\n[3/3] figure")
        labels = {k: v for k, v in ((ga, a.label_a), (gb, a.label_b)) if v}
        figure(a.output, rdf, res, a.nuclear_channel, ga, gb, labels)

    print(f"\nAll outputs in {os.path.abspath(a.output)}")


if __name__ == "__main__":
    main()
