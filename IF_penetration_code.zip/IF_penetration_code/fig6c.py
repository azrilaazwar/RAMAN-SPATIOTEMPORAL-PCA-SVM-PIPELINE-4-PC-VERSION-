import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats

R = "pipeline_results"
prof = pd.read_csv(f"{R}/prof_equatorial.csv")
core = pd.read_csv(f"{R}/core_stats.csv")
sweep = np.round(np.arange(0.2, 0.81, 0.1), 2)

def cw(g, f, col):
    g = g.dropna(subset=[col]); c = g[g.r_mid < f]
    return np.average(c[col], weights=c.n_px) / np.average(g[col], weights=g.n_px)

# Nuclear (Hoechst) control per batch: raw core/whole, A2058 vs A2058-TM
nuc = []
for b in ["B1", "B2"]:
    h = prof[(prof.channel == "Hoechst") & (prof.batch == b)]
    for f in sweep:
        v = {cl: [cw(g, f, "mean_bgsub") for _, g in h[h.cell_line == cl].groupby("spheroid")]
             for cl in ["A2058", "A2058TM"]}
        nuc.append(dict(batch=b, core_fraction=f,
                        p=stats.ttest_ind(v["A2058"], v["A2058TM"], equal_var=False).pvalue))
nuc = pd.DataFrame(nuc)

PAL = {"CAIX": "#D55E00", "COUPTF1": "#009E73", "Ki67": "#E69F00", "p27": "#CC79A7"}
NAME = {"CAIX": "CA IX", "COUPTF1": "COUP-TF1", "Ki67": "Ki-67", "p27": "p27"}
INK, MUT, GRID, NUC = "#1b1b1b", "#5a5a5a", "#dcdcda", "#7a7a7a"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
    "axes.edgecolor": MUT, "axes.labelcolor": INK, "text.color": INK,
    "xtick.color": MUT, "ytick.color": MUT, "axes.linewidth": .8,
    "legend.frameon": False})

def panel(ax, markers, batch, logy, lab_right=False):
    ax.grid(True, color=GRID, lw=.6, zorder=0); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    ax.axvspan(0.195, 0.805, color="none")
    n = nuc[nuc.batch == batch]
    ax.plot(n.core_fraction, n.p, color=NUC, lw=1.4, ls="--", marker="o", ms=4,
            mfc="white", zorder=2)
    for m in markers:
        s = core[(core.channel == m) & (core["mode"] == "norm")].sort_values("core_fraction")
        ax.plot(s.core_fraction, s.p, color=PAL[m], lw=2, zorder=3)
        sig = s.p < 0.05
        ax.scatter(s.core_fraction[sig], s.p[sig], s=30, color=PAL[m],
                   edgecolor="white", linewidth=.8, zorder=4)
        ax.scatter(s.core_fraction[~sig], s.p[~sig], s=30, facecolor="white",
                   edgecolor=PAL[m], linewidth=1.4, zorder=4)
    ax.axhline(0.05, color=INK, lw=1, ls=":", zorder=1)
    ax.set_xlim(0.17, 0.83); ax.set_xticks(sweep)
    ax.set_xlabel("Core radius fraction")
    ax.set_ylabel("p-value (A2058 vs A2058-TM)")
    if logy:
        ax.set_yscale("log"); ax.set_ylim(5e-4, 1.3)
        if lab_right:   # clear gap between Ki-67 (above) and p27 (below)
            ax.text(0.45, 0.044, "p = 0.05", fontsize=7, ha="center", va="top")
        else:
            ax.text(0.185, 0.056, "p = 0.05", fontsize=7, ha="left", va="bottom")
    else:
        ax.set_ylim(0, 1.02)
        ax.text(0.815 if lab_right else 0.185, 0.065, "p = 0.05", fontsize=7,
                ha="right" if lab_right else "left", va="bottom")
    h = [Line2D([0], [0], color=PAL[m], lw=2, marker="o", ms=5,
                mec=PAL[m], label=NAME[m]) for m in markers]
    h.append(Line2D([0], [0], color=NUC, lw=1.4, ls="--", marker="o", ms=4,
                    mfc="white", label="Hoechst (normalization reference)"))
    ax.legend(handles=h, fontsize=7, loc="upper center",
              bbox_to_anchor=(0.5, -0.22), ncol=2, handlelength=2.2, columnspacing=1.2)

for logy, tag in [(True, "log"), (False, "linear")]:
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.2))
    fig.subplots_adjust(wspace=0.32, bottom=0.33, top=0.95, left=0.09, right=0.98)
    panel(axes[0], ["CAIX", "COUPTF1"], "B1", logy)
    panel(axes[1], ["Ki67", "p27"], "B2", logy, lab_right=True)
    fig.text(0.5, 0.005, "Filled markers: p < 0.05   ·   Open markers: p ≥ 0.05   ·   "
             "Markers normalized to Hoechst at matched radius; n = 3 spheroids per line, Welch’s t-test",
             ha="center", fontsize=6.8, color=MUT)
    for ext, kw in [("png", {"dpi": 600}), ("pdf", {}),
                    ("tiff", {"dpi": 600, "pil_kwargs": {"compression": "tiff_lzw"}})]:
        fig.savefig(f"Figure6C_normalized_{tag}.{ext}", bbox_inches="tight", **kw)
    plt.close(fig)

# data table behind the panel
tab = core[core["mode"] == "norm"][["channel", "core_fraction", "mean_a", "sd_a",
                                    "mean_b", "sd_b", "p"]].copy()
tab.insert(0, "batch", tab.channel.map({"CAIX": "B1", "COUPTF1": "B1", "Ki67": "B2", "p27": "B2"}))
tab = pd.concat([tab, nuc.assign(channel="Hoechst_reference")[["batch", "channel", "core_fraction", "p"]]])
tab.to_csv("Figure6C_data.csv", index=False)
print(nuc.pivot(index="core_fraction", columns="batch", values="p").round(3))
