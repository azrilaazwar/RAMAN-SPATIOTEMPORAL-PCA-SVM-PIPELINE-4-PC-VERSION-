"""Supplementary Figure S7: per-slice plane selection and segmentation (method of record).
Reads results/prof_axial.csv and results/geometry.csv from if_penetration_pipeline.py,
plus the nuclear TIFF stacks for the representative segmentations."""
import os, sys, numpy as np, pandas as pd, tifffile, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu, gaussian

R = sys.argv[1] if len(sys.argv) > 1 else "results"
D = sys.argv[2] if len(sys.argv) > 2 else "IF of Spheroid"
PX, DZ = 0.6215, 5.0
COL = {"A2058": "#0072B2", "A2058TM": "#D55E00"}
NAME = {"A2058": "A2058", "A2058TM": "A2058-TM"}
INK, MUT, GRID = "#1b1b1b", "#5a5a5a", "#dcdcda"
plt.rcParams.update({"font.size": 8, "axes.edgecolor": MUT, "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": MUT, "ytick.color": MUT, "axes.linewidth": .8,
    "legend.frameon": False})

ax_df = pd.read_csv(os.path.join(R, "prof_axial.csv"))
geo = pd.read_csv(os.path.join(R, "geometry.csv")).set_index("spheroid")
area = ax_df[ax_df.channel == "Hoechst"][["spheroid", "cell_line", "z", "area_px"]].drop_duplicates()

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from if_penetration_pipeline import segment_slice   # identical segmentation to the analysis

fig = plt.figure(figsize=(7.4, 6.6))
gs = fig.add_gridspec(2, 2, hspace=.42, wspace=.28, top=.95, bottom=.07, left=.09, right=.98)

for j, cl in enumerate(["A2058", "A2058TM"]):
    ax = fig.add_subplot(gs[0, j])
    ax.grid(True, color=GRID, lw=.6, zorder=0); ax.set_axisbelow(True)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    for sp, g in area[area.cell_line == cl].groupby("spheroid"):
        g = g.sort_values("z")
        d_um = 2 * np.sqrt(g.area_px / np.pi) * PX
        ax.plot(g.z * DZ, d_um, color=COL[cl], lw=1.4, alpha=.85, zorder=2)
        zeq = int(geo.loc[sp, "z_eq"])
        ax.scatter(zeq * DZ, geo.loc[sp, "diam_um"], s=36, color=COL[cl],
                   edgecolor="white", linewidth=.9, zorder=3)
    ax.set_xlabel("Depth into z-stack (µm)")
    ax.set_ylabel("Segmented nuclear cross-section\n(equivalent diameter, µm)")
    ax.set_title(f"{'AB'[j]}   {NAME[cl]}", loc="left", fontsize=9, weight="bold")
    ax.set_ylim(0, 440)

# representative segmentations: the spheroid closest to the median diameter per line
for j, cl in enumerate(["A2058", "A2058TM"]):
    g = geo[geo.cell_line == cl]
    sp = (g.diam_um - g.diam_um.median()).abs().idxmin()
    st = tifffile.imread(os.path.join(D, f"{sp}_Hoechst.tif")).astype(np.float32)
    zeq = int(geo.loc[sp, "z_eq"]); img = st[zeq]
    m = segment_slice(img); cy, cx = ndi.center_of_mass(m); Rp = np.sqrt(m.sum() / np.pi)
    ax = fig.add_subplot(gs[1, j])
    lo, hi = np.percentile(img, [1, 99.5])
    ax.imshow(np.clip((img - lo) / (hi - lo), 0, 1) ** 0.5, cmap="gray", interpolation="nearest")
    ax.contour(m, levels=[.5], colors=[COL[cl]], linewidths=1.4)
    th = np.linspace(0, 2 * np.pi, 400)
    for f in (0.2, 0.6, 0.8):
        ax.plot(cx + f * Rp * np.cos(th), cy + f * Rp * np.sin(th), color="white",
                lw=.6, ls=":", alpha=.9)
    ax.plot(cx + .4 * Rp * np.cos(th), cy + .4 * Rp * np.sin(th), color="#E69F00", lw=1.3)
    ax.plot(cx, cy, "+", color="white", ms=8, mew=1.2)
    pad = 1.15 * Rp
    ax.set_xlim(cx - pad, cx + pad); ax.set_ylim(cy + pad, cy - pad)
    sb = 100 / PX
    x0, y0 = cx + pad - sb - 0.08 * pad, cy + pad - 0.10 * pad
    ax.plot([x0, x0 + sb], [y0, y0], color="white", lw=2.2)
    ax.text(x0 + sb / 2, y0 - 0.05 * pad, "100 µm", color="white", ha="center", fontsize=7)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_title(f"{'CD'[j]}   {NAME[cl]} — {sp.split('_',1)[1].replace('_',' ')}, "
                 f"z = {zeq*DZ:.0f} µm", loc="left", fontsize=9, weight="bold")

from matplotlib.lines import Line2D
h = [Line2D([0], [0], color=COL["A2058"], lw=1.4, label="Spheroid boundary / A2058"),
     Line2D([0], [0], color=COL["A2058TM"], lw=1.4, label="Spheroid boundary / A2058-TM"),
     Line2D([0], [0], color="#E69F00", lw=1.3, label="Core boundary (ρ = 0.4)"),
     Line2D([0], [0], color=MUT, lw=.8, ls=":", label="ρ = 0.2, 0.6, 0.8"),
     Line2D([0], [0], marker="o", color="w", markerfacecolor=MUT, ms=6, label="Selected plane (A, B)")]
fig.legend(handles=h, loc="lower center", ncol=3, fontsize=7, bbox_to_anchor=(.5, -.035))
for ext, kw in [("png", {"dpi": 600}), ("pdf", {}),
                ("tiff", {"dpi": 600, "pil_kwargs": {"compression": "tiff_lzw"}})]:
    fig.savefig(f"SupplementaryFigure_S7_plane_selection.{ext}", bbox_inches="tight", **kw)
print("saved")
