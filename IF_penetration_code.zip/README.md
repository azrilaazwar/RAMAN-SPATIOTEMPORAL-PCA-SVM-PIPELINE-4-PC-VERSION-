# IF depth-attenuation analysis

Analysis code for the whole-mount immunofluorescence section of:

> *Spatiotemporal Raman Spectroscopy and Machine Learning Classification Reveal
> Thrombomodulin-Associated Metabolic Compartmentalization in Hypoxic Melanoma Spheroids*

This implements, end to end, the procedure described in **Supplementary Information Section S2.7**.

---

## What it does and why

Whole-mount immunofluorescence of an intact spheroid is degraded with depth by two
processes: limited antibody penetration, and optical attenuation — the latter worsened
when an air objective is focused into aqueous fixed tissue.

Both act on **every channel of a given specimen**, so a raw radial intensity profile
conflates marker biology with a shared attenuation term.

The geometry makes this concrete. For a sphere of radius *R* imaged along *z*, a voxel
lying in the equatorial plane at normalised radius ρ has overlying tissue thickness

```
t(ρ) = R · √(1 − ρ²)
```

maximal at the centre (*t = R*) and zero at the rim. **Attenuation alone therefore
predicts a bright rim and a dark core, with no biological difference required.**

The nuclear counterstain is the internal control. Hoechst 33342 labels all nuclei, so
its radial profile should be roughly flat absent attenuation. Dividing each marker by
the nuclear channel at matched radius cancels the shared multiplicative attenuation to
first order.

---

## Install

```bash
pip install -r requirements.txt
```

Requires Python ≥ 3.9.

---

## Input format

A folder of **single-channel TIFF z-stacks**, named:

```
{cellline}_{batch}_{spheroid}_{channel}.tif
```

```
A2058_B1_S1_Hoechst.tif     A2058TM_B1_S1_Hoechst.tif
A2058_B1_S1_CAIX.tif        A2058TM_B1_S1_CAIX.tif
A2058_B1_S1_COUPTF1.tif     A2058TM_B1_S1_COUPTF1.tif
A2058_B2_S1_Hoechst.tif     A2058TM_B2_S1_Hoechst.tif
A2058_B2_S1_Ki67.tif        A2058TM_B2_S1_Ki67.tif
A2058_B2_S1_p27.tif         A2058TM_B2_S1_p27.tif
```

Rules:

- no underscores inside any of the four fields;
- every spheroid must include the nuclear channel (default name `Hoechst`);
- all channels of one spheroid must share dimensions and the same optical planes;
- export raw 16-bit single-channel stacks (Fiji → Image → Colour → Split Channels).
  Do **not** use contrast-adjusted or RGB-merged exports, or rendered snapshots.

---

## Run

```bash
python if_penetration_pipeline.py \
    --input  "./IF of Spheroid" \
    --output ./results \
    --pixel-size 0.6215 \
    --z-step 5.0 \
    --group-a A2058 \
    --group-b A2058TM \
    --label-b "A2058-TM"
```

Re-run statistics and the figure without re-reading the image stacks:

```bash
python if_penetration_pipeline.py --input "./IF of Spheroid" \
    --output ./results --stages analyse,figure \
    --group-a A2058 --group-b A2058TM --label-b "A2058-TM"
```

### Options

| Flag | Default | Meaning |
|---|---|---|
| `--nuclear-channel` | `Hoechst` | channel used for segmentation and normalisation |
| `--bins` | `20` | radial annuli of equal normalised width |
| `--pixel-size` | `1.0` | µm per pixel (for reporting diameters) |
| `--z-step` | `1.0` | µm between optical sections |
| `--bg-gap` | `10` | mask dilation (px) before sampling background |
| `--core-sweep` | `0.2,0.8,0.1` | min,max,step of the core-radius sweep |
| `--stages` | all | any subset of `extract,analyse,figure` |
| `--label-a`/`--label-b` | — | display names for figure titles |

Runtime is dominated by image I/O: roughly 3 minutes for 36 stacks totalling ~2 GB.

---

## Outputs

| File | Contents |
|---|---|
| `geometry.csv` | per spheroid: equatorial diameter, equatorial plane index, section count, axial span |
| `prof_equatorial.csv` | radial profiles — spheroid × channel × bin, raw and background-subtracted |
| `prof_axial.csv` | per-section rim and core intensity (depth-decay data) |
| `normalised_profiles.csv` | marker ÷ nuclear at matched radius |
| `test1_nuclear_deficit.csv` | nuclear core/rim ratio per spheroid |
| `channel_collapse.csv` | across-channel spread of the rim-normalised profile, per cell line |
| `core_stats.csv` | core/whole ratios and Welch p-values, raw vs normalised, across the sweep |
| `report.txt` | human-readable summary of all tests |
| `figure.png` / `figure.pdf` | six-panel summary |

---

## Method summary

| Stage | S2.7 § | What happens |
|---|---|---|
| Segmentation | S2.7.2 | Nuclear channel: Gaussian σ = 2 px → Otsu → 9×9 closing → hole fill → largest component |
| Equatorial plane | S2.7.2 | Section of maximal nuclear cross-sectional area; its centroid and equivalent-circle radius are applied unchanged to every channel of that spheroid |
| Background | S2.7.3 | Per channel, median of pixels outside the mask dilated by `--bg-gap` px |
| Radial profiling | S2.7.3 | 20 concentric annuli of equal normalised width; mask pixels only |
| Axial decay | S2.7.4 | Per section, mean intensity within rim (ρ > 0.85) and core (ρ < 0.30) of that section's own mask |
| Normalisation | S2.7.5 | `I_marker(ρ) / I_nuclear(ρ)`, background-subtracted annulus means |
| Statistics | S2.7.6 | Core/whole ratio per spheroid, pixel-count weighted; Welch's t-test between cell lines; swept across core-radius fractions. **The experimental unit is the spheroid, never the pixel or the annulus.** |

---

## Interpreting the output

- **Nuclear core/rim near 1.0** — attenuation is not limiting; raw radial profiles may be
  read as biology.
- **Nuclear core/rim well below 0.5** — severe depth-dependent loss; raw radial profiles
  are not interpretable without correction.
- **Low across-channel SD** — every channel follows the same radial curve, so one shared
  attenuation process explains the pattern.
- **High across-channel SD** — genuine marker-specific structure sits on top of the
  attenuation.
- **`SURVIVAL` in the report** — whether each marker's between-group significance persists,
  is lost, or emerges after normalisation.

---

## Limitations

- Normalisation is **first-order**: it cancels multiplicative attenuation common to all
  channels, but not wavelength-dependent differences in scattering and absorption (405 nm
  penetrates less well than 594 nm).
- A declining nuclear profile is **ambiguous in principle** — in a necrotic core nuclei
  genuinely are lost. Magnitude, consistency across specimens, and the degree of
  channel collapse are what distinguish artefact from biology.
- The equatorial plane is itself **attenuation-biased**: because deeper sections lose
  signal, Otsu segmentation shrinks them, so the apparent maximum-area plane may sit
  shallower than the true equator. This biases toward *underestimating* the artefact.
- Segmentation assumes one roughly convex spheroid per field.

---

## Licence

MIT.
